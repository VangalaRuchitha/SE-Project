<?php
session_start(); // Ensure session is started
header("location: ../posBackend/posTable.php");
